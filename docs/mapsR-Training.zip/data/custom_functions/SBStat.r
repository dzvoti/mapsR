

coverage_srs<-function(N,n,img,p){
P<-p+0.5*(1-p)
mu<-mean(img)
NR<-nrow(img)
NC<-ncol(img)
estima<-matrix(nrow=N,ncol=3)
X<-vector("numeric",n)
for (i in 1:N){
rcol<-sample(1:NR,n,replace=T)
rrow<-sample(1:NC,n,replace=T)
if(i==1){
plot(rcol,rrow,pch=16,col="red",xlim=c(0,NC),ylim=c(0,NR))
}
for(j in 1:n){
X[j]<-img[rcol[j],rrow[j]]
}
st.err<-abs(mean(X)-mu)/(sd(X)/sqrt(n))
if(st.err<=qt(P,(n-1))){estima[i,3]<-1}else{estima[i,3]<-0}
estima[i,1]<-mean(X)
estima[i,2]<-sd(X)
}
mmean<-mean(estima[,1])
msd<-mean(estima[,2])
cov<-mean(estima[,3])
op<-matrix(nrow=2,ncol=3)
colnames(op)<-c("Mean","St.Dev","Coverage")
rownames(op)<-c("Population","Samples")
op[1,]<-c(mu,sd(img),p)
op[2,]<-c(mmean,msd,cov)
return(round(op,2))
}

coverage_rtr<-function(N,m,k,img,p){
P<-p+0.5*(1-p)
n<-m*k
mu<-mean(img)
NR<-nrow(img)
NC<-ncol(img)
estima<-matrix(nrow=N,ncol=3)
X<-vector("numeric",n)
for (i in 1:N){
Rcol<-sample(1:NR,k,replace=T)
Rrow<-sample(1:(NC-m),k,replace=T)
rcol=rep(Rcol,each=m)
rrow<-rep(Rrow,each=m)+rep(seq(0,(m-1)),times=m)
if(i==1){
plot(rcol,rrow,pch=16,col="red",xlim=c(0,NC),ylim=c(0,NR))
}
for(j in 1:n){
X[j]<-img[rcol[j],rrow[j]]
}
st.err<-abs(mean(X)-mu)/(sd(X)/sqrt(n))
if(st.err<=qt(P,(n-1))){estima[i,3]<-1}else{estima[i,3]<-0}
estima[i,1]<-mean(X)
estima[i,2]<-sd(X)
}
mmean<-mean(estima[,1])
msd<-mean(estima[,2])
cov<-mean(estima[,3])
op<-matrix(nrow=2,ncol=3)
colnames(op)<-c("Mean","St.Dev","Coverage")
rownames(op)<-c("Population","Samples")
op[1,]<-c(mu,sd(img),p)
op[2,]<-c(mmean,msd,cov)
return(round(op,2))
}



Dunnett.wrap<-function(y.name,T.name,C.name,data.df,ANOVA,nr,Nt,prob){

rms.index<-length(ANOVA$Mean)

# Residual mean square

RMS<-ANOVA$Mean[rms.index]

# Residual degrees of freedom

ResDF<-ANOVA$Df[rms.index]

# Number of comparisons to control

q<-Nt-1

#  Now compute standard error of the difference between two treatment means
#

SED<- sqrt(2*RMS/nr)

# Now compute the value of Dunnett's d, for p and ResDF degrees of freedom and alpha
#

d<-qNCDun(prob,ResDF,rho=rep(0.5,q),delta=rep(0,q),n=32,two.sided=T)

y.index<-which(colnames(data.df)==y.name)
T.index<-which(colnames(data.df)==T.name)

means<-tapply(data.df[,y.index],data.df[,T.index],mean)
C.index<-which(rownames(means)==C.name)

Diff_means<-means-means[C.index]

# Now compute the upper and lower bounds of the difference from the control mean

Upper_limit<-Diff_means+d*SED
Lower_limit<-Diff_means-d*SED

op<-cbind(Upper_limit,Lower_limit)
op<-op[-C.index,]

return(list("Title"="Confidence interval for difference from control mean",
"Level"=prob,"Control is"=C.name,"Intervals"=op))
}

# extract sample mean and CI from a simple random sample

srsestimate<-function(X){

output.mat<-matrix(nrow=1,ncol=4)
colnames(output.mat)<-c("Mean", "Standard error", "Upper 95% limit", "Lower 95% limit")
# Compute sample mean and variance, and count the number of observations
# (assuming no missing values)

mean<-mean(X)
variance<-var(X)
samplesize<-length(X)

# Compute the standard error of the mean

sterror<-sqrt(variance/samplesize)

# Compute degrees of freedom and t-value for 95% confidence interval

df<-samplesize-1.0
tval<-qt(0.975,df)

# Compute upper and lower confidence intervals (95%) for the sample mean

ucl<-mean+(tval*sterror)
lcl<-mean-(tval*sterror)

output.mat[1,]<-cbind(mean,sterror,ucl,lcl)
return(output.mat)
}


####################################################################
########################


samplesize<-function(sd,maxsiz,minsiz,L){

ncrit<-("not in range, increase maxsiz")

nss<-(maxsiz-minsiz+1)
ss<-c(minsiz:maxsiz)
ls<-c(1:nss)

df1<-ss[1]-1.0
tval<-qt(0.975,df1)
sterror1<-sd/sqrt(ss[1])
ls1<-(sterror1*tval)

if(ls1<L) {
print("Reduce minimum sample size or target half-width")
ncrit<-("")
} else {
       for (i in 1:nss){
       df<-ss[i]-1.0
       tval<-qt(0.975,df)
       sterror<-sd/sqrt(ss[i])
       ls[i]<-(sterror*tval)
            if (ls[i]<L) {
             if (ls[i-1]>L) {ncrit<-ss[i]}
            }
        }
}
plot(ss,ls, type="l",xlab="Sample size",ylab="Half-width of 95% confidence interval")


print("Sample size")
print(ncrit)
}



# stratified random sampling set up for the 128 x 128 Kenya MSS image

StrRSimage<-function(N,ns,mat){
sample<-StrRSRect(1,128,1,128,0,N,ns,mat)
return(sample)
}


# stratified random sampling from a rectangular region represented in a matrix, dp is decimal places

StrRSRect<-function(yb,yt,xl,xr,dp,N,ns,mat){

stratum<-rep(seq(1,N),rep(ns,N))
xsam<-vector("numeric",(ns*N))
ysam<-vector("numeric",(ns*N))

nrc<-sqrt(N)
intx<-((xr-xl)/nrc)
inty<-((yt-yb)/nrc)

bounds<-matrix(0,N,4)
#upper, lower (x), upper, lower (y)
ico<-0
for (i in 1:nrc){
for (j in 1:nrc){
ico<-ico+1
bounds[ico,1]<-as.numeric((i-1)*intx)
bounds[ico,2]<-as.numeric(i*intx)
bounds[ico,3]<-as.numeric((j-1)*inty)
bounds[ico,4]<-as.numeric(j*inty)
}
}
bounds<-bounds+1

for (i in 1:(ns*N)){
istrat<-stratum[i]
xsam[i]<-round(runif(1,bounds[istrat,1],bounds[istrat,2]),dp)
ysam[i]<-round(runif(1,bounds[istrat,3],bounds[istrat,4]),dp)
}
sample<-mat[cbind(xsam,ysam)]
plot(xsam,ysam,pch=16,col=grey(sample/77),xlab="Easting",ylab="Northing",
xlim=c(1,128),ylim=c(1,128))
lines(c(xl,xr),c(yb,yb),lty=3)
lines(c(xr,xr),c(yt,yb),lty=3)
for (i in 1:N){
x1<-bounds[i,1]
y1<-bounds[i,2]
x2<-bounds[i,3]
y2<-bounds[i,4]

lines(c(x1,x1),c(yb,yt),lty=3)
lines(c(xl,xr),c(y1,y1),lty=3)
lines(c(x2,x2),c(yb,yt),lty=3)
lines(c(xl,xr),c(y2,y2),lty=3)
}

return(cbind(stratum,sample))
}

#####################################################################

strsestimate<-function(strsample,N,output.mat){

# Equal sized strata so relative areas are equal
rarea.mat<-matrix(rep(1/N,N),N,1)


#strsmean and strsvar are the StRS mean and variance
# of the mean

strsmean<-0.0
strsvar<-0.0

# Set up a vectors for variance of stratum means

varmean.mat<-matrix(nrow=N,ncol=1)


# Use describe.by from the psych library to extract stratum means and 
# variances

desc.mat<-describeBy(strsample[,2],strsample[,1],mat=TRUE)

#describeBy substituted for describe.by on 6/3/13

# Extract stratum statistics: numbers of observations, means and SD.  

nobs.mat<-cbind(desc.mat[1:N,4])
means.mat<-cbind(desc.mat[1:N,5])
var.mat<-cbind(desc.mat[1:N,6])

# Compute total sample size
samplesize<-nrow(strsample)

# Compute stratum variance from stratum SD

for (i in 1:N) {var.mat[i,1]<-var.mat[i,1]*var.mat[i,1]}

# Compute variance of stratum means

for (i in 1:N) {varmean.mat[i,1]<-var.mat[i,1]/nobs.mat[i,1]}

# Compute StRS mean

for (i in 1:N) {strsmean<-strsmean+(means.mat[i,1]*rarea.mat[i,1])}

# Compute StRS variance

for (i in 1:N) {strsvar<-strsvar+(varmean.mat[i,1]*rarea.mat[i,1]*rarea.mat[i,1])}

strssd<-sqrt(strsvar)

# Compute effective degrees of freedom (Satterthwaite-Welch)

denom<-(strsvar)^2
num<-0.0
for (i in 1:N) { num<-num+(((varmean.mat[i,1]*rarea.mat[i,1]*rarea.mat[i,1])^2)
/(nobs.mat[i,1]-1.0))}

df<-denom/num


tval<-qt(0.975,df)
ucl<-strsmean+(tval*strssd)
lcl<-strsmean-(tval*strssd)

output.mat<-matrix(nrow=1,ncol=4)
colnames(output.mat)<-c("Mean", "Standard error", "Upper 95% limit", "Lower 95% limit")
output.mat[1,]<-cbind(strsmean,strssd,ucl,lcl)
return(output.mat)
}


plotsam<-function(sites,mat){

sample<-mat[sites]
plot(sites[,1],sites[,2],pch=16,col=grey(sample/77),xlab="Easting",ylab="Northing",
xlim=c(1,128),ylim=c(1,128))

}

gridsam<-function(sites,mat){

sample<-mat[sites]
plot(sites[,1],sites[,2],pch=16,col=grey(sample/77),xlab="Easting",ylab="Northing",
xlim=c(1,128),ylim=c(1,128))
return(cbind(sites,sample))
}

regline<-function(minx,maxx,mod,group){

if(missing(group)){oneline<-T}else{oneline<-F}

if(oneline==T){
yminx<-c(1,minx)%*%mod$coefficients
ymaxx<-c(1,maxx)%*%mod$coefficients
lines(c(minx,maxx),c(yminx,ymaxx),lwd=2,col="red")
} else {

faclevs<-as.vector((unlist(mod$xlevels)))
nlev<-length(faclevs)

datmin<-data.frame(mod$model[1:nlev,])
datmin[,3]<-minx
datmin[,2]<-faclevs

datmax<-data.frame(mod$model[1:nlev,])
datmax[,3]<-maxx
datmax[,2]<-faclevs

Mdmin<-model.matrix(mod$terms,datmin)
Mdmax<-model.matrix(mod$terms,datmax)
ymino<-Mdmin%*%mod$coefficients
ymaxo<-Mdmax%*%mod$coefficients

for(i in 1:nlev){
lines(c(minx,maxx),c(ymino[i,1],ymaxo[i,1]),lwd=2,col=i)
}

}

}


regline_ur<-function(minx,maxx,mod,ngroup=1,parallel=T){
yminx<-c(1,minx)%*%mod$coefficients
ymaxx<-c(1,maxx)%*%mod$coefficients
lines(c(minx,maxx),c(yminx,ymaxx),lwd=2,col="red")
}

SumSq.TrEff<-function(y,fac,data.df){

col_y<-which(colnames(data.df)==y)
col_f<-which(colnames(data.df)==fac)
Y<-data.df[,col_y]
F<-data.df[,col_f]
NV<-nlevels(F)

means.mat<-tapply(Y,F,mean)
lev_sum<-colSums(table(Y,F))
Gmean<-sum(means.mat*lev_sum)/sum(lev_sum)
sumtau2<-sum((means.mat-Gmean)^2)
}

SumSq.TrEff.hyp<-function(tmeans){
Gmean<-mean(tmeans)
sumtau2<-sum((tmeans-Gmean)^2)
}


############
make.contrasts<-function(trt,mod,data.df){
ifac<-which(colnames(data.df)==trt)
levs<-levels(data.df[,ifac])
m<-nlevels(data.df[,ifac])
CM<-matrix(nrow=(m-1),ncol=m)
colnames(CM)<-levs
conames<-vector("character",(m-1))
if(m==0) stop(paste("No factor called",trt, "in dataframe"))
message(paste("With",m,"levels you have",m-1,"orthogonal contrasts"),appendLF=T)
message("Enter the sets of coefficients for each contrast in turn",appendLF=T)
message(paste("Levels of",trt,"are in order",toString(levs)))

repeat{
  for(i in 1:(m-1)){
conames[i]<-paste("Contrast",i,sep=".")
repeat{for(j in 1:m){
CM[i,j]<-as.numeric(readline(paste("Enter coefficient",j,"for level",levs[j],
                        "in contrast",i,":  ")))
} #loop of j over number of levels
if(sum(CM[i,])==0){break}else{message(paste(
  "Coefficients for contrast",i,"should sum to zero. Redo"),appendLF=T)}    
} #repeat loop which is broken once orthogonal set entered
} #loop of i over number of contrasts
rownames(CM)<-conames
TM<-CM%*%t(CM)
diag(TM)<-0
errs<-which(TM!=0, arr.ind =T)
errsmin<-errs[which(errs[,1]<errs[,2]),]
colnames(errsmin)<-c("A","B")
nerrs<-nrow(errsmin)
if(nerrs==0){break}else{
  message("Non-orthogonal set",appendLF=T)
  message(paste("The following contrasts are non-orthogonal:"))
  for(k in 1:nerrs){
    c1<-errsmin[k,1]
    c2<-errsmin[k,2]
    message(paste("Contrast",c1,"and",c2))
    print(CM[c1,])
    print(CM[c2,])
    
  }
  message("Check the contrast coefficients, and re-enter them")
}#repeat loop over full set of contrasts broken

}#all coefficients set up
#rescale
temp.m<-rbind(rep(1/m,m),CM)

CM<-(solve(temp.m))[,-1]

message("Contrast coefficients")
print(CM)
OP<-list(trt=CM)
names(OP)<-trt
return(OP)
}
################

Tea_taste<-function(s,N,p0){
  pv<-round((1-pbinom((s-1),N,p0)),3)
  message("The probability of getting ",s," or more successes out of ",N," trials")
  message("where the probability of success in a single trial is ",p0)
if(pv>=0.001){
  message("is ",pv)}else{
  message("is < 0.001")}
}


multisample<-function(n,mat){
  par(mfrow=c(2,2))
  varm<-round(((sd(mat))^2),2)
  mmean<-round(mean(mat),1)
  lab1<-paste("Variance =", varm," mean= ",mmean)
  hist(mat,main=lab1,xlab="Raw data values",cex.main=0.85,cex.lab=0.9)
  qqnorm(mat)
  mv<-vector("numeric",1000)
  for (i in 1:1000){
    mv[i]<-mean(SRSimage(n,mat))
    print(i)
  }
  varmean<-round(var(mv),2)
  mmean<-round(mean(mv),1)
  lab2<-paste("Variance =" ,varmean," mean= ",mmean)
  lab3=paste("Means of 1000 samples size =",n)
  
  hist(mv,main=lab2,xlab=lab3,cex.main=0.85,cex.lab=0.9)
  qqnorm(mv)
  }


# simple random sampling set up for the 128 x 128 Kenya MSS image

SRSimage<-function(n,mat){
  sample<-SRSRect(1,128,1,128,0,n,mat)
  return(sample)
}


# simple random sampling from a rectangular region represented in a matrix, dp is decimal places

SRSRect<-function(yb,yt,xl,xr,dp,n,mat){
  
  
  xsam<-round(runif(n,xl,xr),dp)
  ysam<-round(runif(n,yb,yt),dp)
  sample<-mat[cbind(xsam,ysam)]
  plot(xsam,ysam,pch=16,col=grey(sample/77),xlab="Easting",ylab="Northing",
       xlim=c(1,128),ylim=c(1,128))
  return(sample)
}

#############################################################################
#
# SUMMARY STATISTICS
#
#

skew<-function(x){

# compute coefficient of skewness of data in x

x<-na.drop(x)
n<-length(x)
xd<-x-mean(x)
mu3<-sum(xd^3)/(n-1)
mu<-sqrt(sum(xd^2)/(n-1))
sk<-mu3/(mu^3)
return(sk)
}

#############################################################################

kurt<-function(x){

# compute coefficient of kurtosis of data in x

x<-na.drop(x)
n<-length(x)
xd<-x-mean(x)
mu4<-sum(xd^4)/(n-1)
mu<-sqrt(sum(xd^2)/(n-1))
sk<-(mu4/(mu^4))-3
return(sk)
}

################################################################################

ocskew<-function(x){

# compute the octile skewness of values in x

x<-na.drop(x)
Ocs<-quantile(x,c(1/8,0.5,7/8))
os<-((Ocs[3]-Ocs[2])-(Ocs[2]-Ocs[1]))/(Ocs[3]-Ocs[1])
return(os)
}

###########################################################################

summa<-function(x,sigf){

# compute summary statistics of values in x

if(missing(sigf)){rosig<-F}else{rosig<-T}


x<-na.drop(x)
Q1<-quantile(x,prob=0.25)
Q3<-quantile(x,prob=0.75)
Q2<-quantile(x,prob=0.5)
hspread<-Q3-Q1
Fu<-Q3+3*hspread
Fl<-Q1-3*hspread

# ols,oll: values below and above outer fences
# posols,posoll: values below and above inner fences 
# (so ols and posols overlap, as do oll and posoll
#

ols<-which(x<Fl)
oll<-which(x>Fu)
posols<-which(x<(Q1-1.5*hspread))
if(length(posols)==0){
lw<-min(x)}else{
lw<-min(x[-posols])}
posoll<-which(x>(Q3+1.5*hspread))
if(length(posoll)==0){
uw<-max(x)}else{
uw<-max(x[-posoll])}

ol<-c(ols,oll) # combined outlier set

nol<-length(ol)

outp<-matrix(c(mean(x),Q2,Q1,Q3,var(x),sqrt(var(x)),skew(x),ocskew(x),kurt(x),nol),1,10)

if(rosig=="TRUE"){outp<-signif(outp,sigf)}

colnames(outp)<-c("Mean","Median",
"Quartile.1", "Quartile.3","Variance","SD","Skewness",
"Octile skewness","Kurtosis",
"No. outliers")


return(outp)

}

####################################################################

summaplot<-function(x,varname){

# plot a histogram with boxplot and QQ plot of data in x indicating
# any probable outliers by Tukey's criterion

x<-na.drop(x)
if(missing(varname)){varname<-"x"}

Q1<-quantile(x,prob=0.25)
Q3<-quantile(x,prob=0.75)
Q2<-quantile(x,prob=0.5)
hspread<-Q3-Q1
Fu<-Q3+3*hspread
Fl<-Q1-3*hspread


# ols,oll: values below and above outer fences
# posols,posoll: values below and above inner fences 
# (so ols and posols overlap, as do oll and posoll
#
ols<-which(x<Fl)
oll<-which(x>Fu)
posols<-which(x<(Q1-1.5*hspread))
if(length(posols)==0){
lw<-min(x)}else{
lw<-min(x[-posols])}
posoll<-which(x>(Q3+1.5*hspread))
if(length(posoll)==0){
uw<-max(x)}else{
uw<-max(x[-posoll])}

ol<-c(ols,oll) # combined outlier set
par(mfrow=c(1,2))
ymax<-max((hist(x,plot=F))$counts)
hist(x,main="",col="AliceBlue", xlab=varname,ylim=c(0,(ymax*1.25)))

boxmin<-ymax*1.1
boxmax<-ymax*1.2
boxmid<-ymax*1.15

lines(c(Q1,Q3),c(boxmin,boxmin))
lines(c(Q1,Q3),c(boxmax,boxmax))
lines(c(Q1,Q1),c(boxmin,boxmax))
lines(c(Q3,Q3),c(boxmin,boxmax))
lines(c(Q1,lw),c(boxmid,boxmid))
lines(c(Q3,uw),c(boxmid,boxmid))
lines(c(Q2,Q2),c(boxmin,boxmax),lwd=2)

lines(c(Fu,Fu),c(10,boxmid),lty=5,col="red")
lines(c(Fl,Fl),c(10,boxmid),lty=5,col="red")

qqn<-qqnorm(x,main="",pch=16)
qqline(x)
points(qqn$x[ol],qqn$y[ol],pch=16,col="red")
# Reset the plot window to one plot
par(mfrow=c(1,1))
}
####################################################################

histplot<-function(x,varname){

# plot a histogram with boxplot in x indicating
# any probable outliers by Tukey's criterion

x<-na.drop(x)
if(missing(varname)){varname<-"x"}

Q1<-quantile(x,prob=0.25)
Q3<-quantile(x,prob=0.75)
Q2<-quantile(x,prob=0.5)
hspread<-Q3-Q1
Fu<-Q3+3*hspread
Fl<-Q1-3*hspread


# ols,oll: values below and above outer fences
# posols,posoll: values below and above inner fences 
# (so ols and posols overlap, as do oll and posoll
#
ols<-which(x<Fl)
oll<-which(x>Fu)
posols<-which(x<(Q1-1.5*hspread))
if(length(posols)==0){
lw<-min(x)}else{
lw<-min(x[-posols])}
posoll<-which(x>(Q3+1.5*hspread))
if(length(posoll)==0){
uw<-max(x)}else{
uw<-max(x[-posoll])}

ol<-c(ols,oll) # combined outlier set

ymax<-max((hist(x,plot=F))$counts)
hist(x,main="",col="AliceBlue", xlab=varname,ylim=c(0,(ymax*1.25)))

boxmin<-ymax*1.1
boxmax<-ymax*1.2
boxmid<-ymax*1.15

lines(c(Q1,Q3),c(boxmin,boxmin))
lines(c(Q1,Q3),c(boxmax,boxmax))
lines(c(Q1,Q1),c(boxmin,boxmax))
lines(c(Q3,Q3),c(boxmin,boxmax))
lines(c(Q1,lw),c(boxmid,boxmid))
lines(c(Q3,uw),c(boxmid,boxmid))
lines(c(Q2,Q2),c(boxmin,boxmax),lwd=2)

lines(c(Fu,Fu),c(10,boxmid),lty=5,col="red")
lines(c(Fl,Fl),c(10,boxmid),lty=5,col="red")

}
###########################################################################

outliers<-function(x,trim){

# compute summary statistics of values in x

if(missing(trim)){trim<-F}

x<-na.drop(x)
Q1<-quantile(x,prob=0.25)
Q3<-quantile(x,prob=0.75)
Q2<-quantile(x,prob=0.5)
hspread<-Q3-Q1
Fu<-Q3+3*hspread
Fl<-Q1-3*hspread

# ols,oll: values below and above outer fences
# posols,posoll: values below and above inner fences 
# (so ols and posols overlap, as do oll and posoll
#

ols<-which(x<Fl)
oll<-which(x>Fu)
posols<-which(x<(Q1-1.5*hspread))
if(length(posols)==0){
lw<-min(x)}else{
lw<-min(x[-posols])}
posoll<-which(x>(Q3+1.5*hspread))
if(length(posoll)==0){
uw<-max(x)}else{
uw<-max(x[-posoll])}

ol<-c(ols,oll) # combined outlier set

nol<-length(ol)

print(paste(nol," value(s) lie outwith the outer fences (Tukey, 1977)"),quote=F)

if(nol!=0){
print(paste("Outlying values are:"),quote=F)
print(x[ol])
print(paste("Indices of outlying values are"),quote=F)

if(trim==F){
return(ol)}else{
print(ol)
return(x[-ol])
}
}
}

###########################################################################

cor.sig<-function(x,roc=3,roP=3){
  
  require(Hmisc)

  data<-rcorr(as.matrix(x))
  p_value<-round(data$P,roP)
  cor_table<-round(data$r,roc)

  data<-paste(cor_table, sep="")
  data <- matrix(data, ncol=ncol(x))
  diag(data) <- paste(diag(cor_table), " ", sep="")
  data[lower.tri(data, diag = TRUE)] <- ""
  data<-as.vector(data)

  data1<-paste(p_value, sep="")
  data1 <- matrix(data1, ncol=ncol(x))
  diag(data1) <- paste(diag(cor_table), " ", sep="")
  data1[upper.tri(data1, diag = TRUE)] <- ""
  data1<-as.vector(data1)
  
  data2 <- matrix(paste(data, data1, sep=""), ncol=ncol(p_value))
  rownames(data2) <- colnames(p_value)
  colnames(data2)<-colnames(p_value)
  data2<-as.data.frame(data2)
  print(data2)
  }

###############################################################
###############################################################

qqnorm.line<-function(x,col="black"){
  qqnorm(x)
  qqline(x,col=col)
}



###############################################################
###############################################################
na.drop<-function(xin){
noNA<-as.numeric(length(which(is.na(xin)==T)))
if(noNA>0){
x<-as.numeric(na.omit(xin))
print(paste(noNA," missing value(s) removed"),quote=F)
}else{
x<-xin
}
return(x)
}



T_test<-function(variable,groups,data){
TEST<-t.test(data[,variable]~data[,groups],var.equal=T)
message("\n t-test to compare independent random samples from two groups\n " )
resids<-(lm(data[,variable]~data[,groups]))$residuals
par(mfrow=c(1,2))
boxplot(data[,variable]~data[,groups],ylab=variable,xlab=groups)
mtext("Boxplot of values within groups",side=3,adj=0,line=1)
histplot(resids,"Residuals")
mtext("Histogram and boxplot of residuals",side=3,adj=0,line=1)
message("Estimated group means")
print(signif(TEST$estimate,digits=5))
message("\n Difference between group means is ",signif(as.numeric(TEST$estimate[1]-TEST$estimate[2]),digits=4))
message("\n 95% confidence interval for this difference is ",signif(as.numeric(TEST$conf.int[1]),digits=4)," to ",signif(as.numeric(TEST$conf.int[2]),digits=4))
message ("\n The t-statistic is ",signif(TEST$statistic,digits=5)," with ",signif(TEST$parameter,digits=5)," degrees of freedom")
message ("\n The probability of obtaining evidence this strong or stronger")
message ( " if the true difference is zero is ",signif(TEST$p.value,digits=5)) 	
}


Jelly.Bean<-function(){
qual_col_pals = 
brewer.pal.info[brewer.pal.info$colorblind == T,]
col_vector = unlist(mapply(brewer.pal, qual_col_pals$maxcolors, rownames(qual_col_pals)))


ncols<-20
JBean<-vector("character",(5*ncols))
for (i in 1:ncols){
col<-paste("Col",i,sep=("."))
for (j in 1:5){
JBean[(((i-1)*5)+j)]<-col
}
}

AS<-rnorm((ncols*5),10,6)
data.df<-data.frame(AS)
data.df$JB<-factor(JBean)



means<-aggregate(AS~JB, data=data.df, FUN=mean)


min(means[,2])
max(means[,2])
mintr<-which(means[,2]==min(means[,2]))
maxtr<-which(means[,2]==max(means[,2]))
min.col=means[mintr,1]
max.col=means[maxtr,1]
maxas<-max(AS)*1.2
minas<-min(AS)
colvec<-col_vector[seq(5,((ncols+5)*10),10)]
boxplot(AS~JB,data=data.df,col=colvec,cex=0,
        staplewex=0,range=0.000000001,ylim=c(minas,maxas),
        ylab="Acne score",xaxt="n",xlab="")

        mtext("Beans by colour",side=1,line=1)


pv<-(t.test(AS[which(data.df$JB==min.col)],AS[which(data.df$JB==max.col)],var.equal=T))$p.value


if(pv>0.05){
text(10,maxas,"Nothing to see here")}else{
points(min.col,maxas,pch=16,cex=3,col=colvec[min.col])
points(max.col,maxas,pch=16,cex=3,col=colvec[max.col])
arrows(mintr,maxas,maxtr,maxas,code=3)
text ((0.5*(mintr+maxtr)),(maxas*0.9),(paste0("p= ",round(pv,4))))
}
}

